These ScreenShots Consists : 
    VPC, Public and Private Subnet, Route Table, Internet Gateway
    Interconnection b/w VPC and resources
    And Lastly Login into Public virtual System and Private virtual System through EC2 Service.
